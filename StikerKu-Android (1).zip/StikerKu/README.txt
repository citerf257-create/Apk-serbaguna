StikerKu - pembuat stiker WhatsApp (proyek Android Studio)

CARA BUILD APK
1. Pasang Android Studio (Hedgehog / Iguana atau lebih baru) + JDK 17 (sudah termasuk).
2. File > Open > pilih folder StikerKu ini. Tunggu Gradle sync selesai (butuh internet).
3. Colok HP (aktifkan USB debugging) lalu klik Run, ATAU:
   Build > Build Bundle(s)/APK(s) > Build APK(s) untuk menghasilkan file .apk.
   Hasil: app/build/outputs/apk/debug/app-debug.apk

CARA PAKAI
1. Buka aplikasi, pilih foto, atur posisi/zoom/teks.
2. Ketuk "+ Ke Paket WA" untuk tiap stiker (minimal 3, maksimal 30).
3. Ketuk "Tambahkan ke WhatsApp" -> WhatsApp meminta konfirmasi -> stiker muncul di panel stiker.

UBAH NAMA PAKET
app/src/main/java/com/stikerku/app/StickerStore.kt  (PACK_NAME, PUBLISHER)

Syarat WhatsApp: stiker WebP 512x512 maks 100 KB, ikon tray PNG 96x96 (dibuat otomatis dari stiker pertama).
Aplikasi ini belum diuji di perangkat; kalau ada error build, kirim pesan errornya.

BUILD TANPA KOMPUTER (lewat GitHub, cukup browser HP)
1. Buat akun GitHub (gratis) dan buat repository baru.
2. Upload SEMUA isi folder StikerKu ini (termasuk folder .github) ke repository tersebut.
3. Buka tab Actions > "Build APK" > Run workflow. Tunggu sekitar 3-6 menit sampai hijau.
4. Buka hasil run-nya, unduh artifact "StikerKu-apk" (zip), ekstrak, lalu install app-debug.apk.
