package com.stikerku.app

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private lateinit var store: StickerStore
    private var fileCb: ValueCallback<Array<Uri>>? = null

    private val chooser = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCb = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = StickerStore(this)
        web = WebView(this)
        web.setBackgroundColor(Color.BLACK)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.addJavascriptInterface(Bridge(), "Android")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(w: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                fileCb?.onReceiveValue(null)
                fileCb = cb
                return try { chooser.launch(p.createIntent()); true } catch (e: Exception) { fileCb = null; false }
            }
        }
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface fun addSticker(b64: String): Int = store.add(Base64.decode(b64, Base64.DEFAULT))
        @JavascriptInterface fun count(): Int = store.count()
        @JavascriptInterface fun clear() { store.clear() }
        @JavascriptInterface fun addToWhatsApp(): String {
            if (store.count() < 3) return "min3"
            runOnUiThread { openWhatsApp() }
            return "ok"
        }
    }

    private fun openWhatsApp() {
        val i = Intent("com.whatsapp.intent.action.ENABLE_STICKER_PACK").apply {
            putExtra("sticker_pack_id", StickerStore.PACK_ID)
            putExtra("sticker_pack_authority", packageName + ".stickercontentprovider")
            putExtra("sticker_pack_name", StickerStore.PACK_NAME)
        }
        try {
            startActivityForResult(i, 200)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "WhatsApp tidak ditemukan atau versinya terlalu lama", Toast.LENGTH_LONG).show()
        }
    }
}
