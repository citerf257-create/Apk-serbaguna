package com.stikerku.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Menyimpan stiker (WebP 512x512) di folder internal aplikasi. */
class StickerStore(private val ctx: Context) {
    companion object {
        const val PACK_ID = "stikerku_1"
        const val PACK_NAME = "Stiker Saya"   // ganti nama paket di sini
        const val PUBLISHER = "StikerKu"      // ganti nama pembuat di sini
        const val TRAY = "tray.png"
    }

    val dir: File get() = File(ctx.filesDir, "pack").also { it.mkdirs() }
    private val meta: File get() = File(dir, "meta.json")

    fun files(): List<String> = try {
        val a = JSONObject(meta.readText()).getJSONArray("files")
        (0 until a.length()).map { a.getString(it) }
    } catch (e: Exception) { emptyList() }

    fun version(): Int = try { JSONObject(meta.readText()).getInt("version") } catch (e: Exception) { 1 }
    fun count(): Int = files().size

    private fun write(files: List<String>, v: Int) {
        meta.writeText(JSONObject().put("version", v).put("files", JSONArray(files)).toString())
    }

    @Synchronized
    fun add(bytes: ByteArray): Int {
        val f = files().toMutableList()
        if (f.size >= 30) return f.size
        val name = "s_" + System.currentTimeMillis() + ".webp"
        File(dir, name).writeBytes(bytes)
        f.add(name)
        if (f.size == 1) makeTray(bytes)
        write(f, version() + 1)
        return f.size
    }

    private fun makeTray(bytes: ByteArray) {
        val bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
        val t = Bitmap.createScaledBitmap(bm, 96, 96, true)
        File(dir, TRAY).outputStream().use { t.compress(Bitmap.CompressFormat.PNG, 100, it) }
    }

    @Synchronized
    fun clear() {
        val v = version()
        dir.listFiles()?.forEach { it.delete() }
        write(emptyList(), v + 1)
    }
}
