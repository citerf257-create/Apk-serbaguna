package com.stikerku.app

import android.content.ContentProvider
import android.content.ContentValues
import android.content.res.AssetFileDescriptor
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.ParcelFileDescriptor
import java.io.File
import java.io.FileNotFoundException

/** Provider sesuai spesifikasi WhatsApp Sticker Pack. */
class StickerContentProvider : ContentProvider() {
    private val M_ALL = 1
    private val M_ONE = 2
    private val M_STICKERS = 3
    private val M_ASSET = 4
    private lateinit var matcher: android.content.UriMatcher
    private lateinit var authority: String
    private lateinit var store: StickerStore

    override fun onCreate(): Boolean {
        val c = context ?: return false
        authority = c.packageName + ".stickercontentprovider"
        store = StickerStore(c)
        matcher = android.content.UriMatcher(android.content.UriMatcher.NO_MATCH).apply {
            addURI(authority, "metadata", M_ALL)
            addURI(authority, "metadata/*", M_ONE)
            addURI(authority, "stickers/*", M_STICKERS)
            addURI(authority, "stickers_asset/*/*", M_ASSET)
        }
        return true
    }

    override fun query(uri: Uri, projection: Array<String>?, selection: String?, selectionArgs: Array<String>?, sortOrder: String?): Cursor {
        val cur = when (matcher.match(uri)) {
            M_ALL, M_ONE -> packCursor()
            M_STICKERS -> stickerCursor()
            else -> throw IllegalArgumentException("Unknown URI: $uri")
        }
        cur.setNotificationUri(context!!.contentResolver, uri)
        return cur
    }

    private fun packCursor(): MatrixCursor {
        val c = MatrixCursor(arrayOf(
            "sticker_pack_identifier", "sticker_pack_name", "sticker_pack_publisher", "sticker_pack_icon",
            "android_play_store_link", "ios_app_download_link", "sticker_pack_publisher_email",
            "sticker_pack_publisher_website", "sticker_pack_privacy_policy_website",
            "sticker_pack_license_agreement_website", "image_data_version",
            "whatsapp_will_not_cache_stickers", "animated_sticker_pack"))
        c.addRow(arrayOf<Any>(StickerStore.PACK_ID, StickerStore.PACK_NAME, StickerStore.PUBLISHER, StickerStore.TRAY,
            "", "", "", "", "", "", store.version().toString(), 0, 0))
        return c
    }

    private fun stickerCursor(): MatrixCursor {
        val c = MatrixCursor(arrayOf("sticker_file_name", "sticker_emoji", "sticker_accessibility_text"))
        store.files().forEach { c.addRow(arrayOf<Any>(it, "\uD83D\uDE00", "Stiker")) }
        return c
    }

    override fun openAssetFile(uri: Uri, mode: String): AssetFileDescriptor? {
        if (matcher.match(uri) != M_ASSET) throw FileNotFoundException("Bad URI")
        val seg = uri.pathSegments
        val name = seg[seg.size - 1]
        val f = File(store.dir, name)
        if (f.canonicalPath.startsWith(store.dir.canonicalPath) && f.exists()) {
            return AssetFileDescriptor(ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY), 0, AssetFileDescriptor.UNKNOWN_LENGTH)
        }
        throw FileNotFoundException(name)
    }

    override fun getType(uri: Uri): String? = when (matcher.match(uri)) {
        M_ALL -> "vnd.android.cursor.dir/vnd.$authority.metadata"
        M_ONE -> "vnd.android.cursor.item/vnd.$authority.metadata"
        M_STICKERS -> "vnd.android.cursor.dir/vnd.$authority.stickers"
        M_ASSET -> if (uri.lastPathSegment?.endsWith(".png") == true) "image/png" else "image/webp"
        else -> throw IllegalArgumentException("Unknown URI: $uri")
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException()
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int = throw UnsupportedOperationException()
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<String>?): Int = throw UnsupportedOperationException()
}
